#Osagiede John Osemwengie Work
import matplotlib.pyplot as plt

#this block of code visualizes the training score for
# various classifiers in a bar chart
classifiers = ['SVM', 'NB', 'RF', 'DT', 'GB', 'LR']
values = [99.8, 88.0, 100.0, 99.0, 99.8, 99.4]
f = plt.figure(figsize =(8, 8), num = 10)
plt.title('Training Score for different classifiers')
plt.xlabel('Classifier algorithm')
plt.ylabel('Training Score Accuracy')
plt.bar(classifiers, values)
plt.show()


#this block of code visualizes the testing score for
# various classifiers in a bar chart
classifiers = ['SVM', 'NB', 'RF', 'DT', 'GB', 'LR']
values = [99.9, 87.9, 99.9, 99.0, 99.7, 99.3]
f = plt.figure(figsize =(8, 8), num = 10)
plt.title('Testing Score for different classifiers')
plt.xlabel('Classifier algorithm')
plt.ylabel('Testing Score Accuracy')
plt.bar(classifiers, values)
plt.show()


#this block of code visualizes the training time for
# various classifiers in a bar chart
classifiers = ['SVM', 'NB', 'RF', 'DT', 'GB', 'LR']
values = [218.0, 1.1, 17.0, 2.4, 633.2, 92.9]
f = plt.figure(figsize =(8, 8), num = 10)
plt.title('Training time for different classifiers')
plt.xlabel('Classifier algorithm')
plt.ylabel('Training Time (ms)')
plt.bar(classifiers, values)
plt.show()


#this block of code visualizes the testing time for
#various classifiers in a bar chart

classifiers = ['SVM', 'NB', 'RF', 'DT', 'GB', 'LR']
values = [0.19, 1.5, 0.14, 0.14, 2.95, 0.09]
f = plt.figure(figsize =(8, 8), num = 10)
plt.title('Testing time for different classifiers')
plt.xlabel('Classifier algorithm')
plt.ylabel('Testing Time (ms)')
plt.bar(classifiers, values)
plt.show()


