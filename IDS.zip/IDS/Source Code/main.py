#Osagiede John Osemwengie Work
#################################################################
# Pyhton program to implement a tkinter application which
# will allow the user to load the network packet dataset and
# distinguish the connection as normal or bad connections

# author :
# date   : 09/09/2023
################################################################

#import the neccessary libraries
import numpy as np
import joblib
import tkinter as tk
import tkinter.scrolledtext as st
from tkinter import ttk
from tkinter import *
from PIL import ImageTk, Image
from tkinter import filedialog as fd
# create the root window
root = tk.Tk()
root.title('Intrusion Detection System')
root.resizable(False, False)
root.geometry('800x700')

#function to perform the prediction of loaded dataset
def predict(filename):
    pdata = []
    #open the input file
    saveFile = open(filename, "r")
    #read all the lines of the file
    lines = saveFile.readlines()
    #iterate through each line of the file
    for t in lines:
        #convert the line data to numpy array
        np_array = np.array([float(x) for x in t.split(',')])
        #append the numpy array to list
        pdata.append(np_array)
    #insert the messages to result area of the pplication
    text_area.insert(tk.INSERT, "Loading the Machine Learning Model.......\n")
    # load the prediction model
    rf_from_joblib = joblib.load('model.pkl')
    text_area.insert(tk.INSERT, "Predicting the dataset....\n")
    #predict the data
    prediction_result = rf_from_joblib.predict(pdata)
    id = 0
    summary_dict = {}
    #iterate through the predicted data
    for t in prediction_result:
        # append the result to result area
        message = "Analyzing Packet " + str(id) + "\n" + lines[id] + "Result: " + str(t) + "\n\n"
        text_area.insert(tk.INSERT, message)
        #compute the summary of the result
        if t in summary_dict:
            count = summary_dict[t]
            count = count + 1
            summary_dict[t] = count
        else:
            summary_dict[t] = 1

        id = id + 1
    #print the summary to result area
    text_area.insert(tk.INSERT, "Total packets analyzed: " + str(id))
    summary = "\n\nSummary:"
    for item in summary_dict:
        summary = summary + "\n" + item + ":" + str(summary_dict[item])
    text_area.insert(tk.INSERT, summary)
    #move to  the end of the result area
    text_area.yview(END)

#Function to load the file from system and predict the same
def load_file():
    #allowed file types
    file_types = (
        ('text files', '*.txt'),
        ('All files', '*.*')
    )
    #load the file
    filename = fd.askopenfilename(
        title='Choose a dataset',
        initialdir='/',
        filetypes=file_types)
    #predict the data
    try:
        predict(filename)
    except:
        print("Sorry the loaded file is not valid!")


#function to clear the result area
def clear_result():
    text_area.delete(1.0, END)


#define the header label for application
label = Label(root, text="Intrusion Detection System", height=2, width=40, font=('Times', 24))
label.pack()

#define the image to be loaded
img = ImageTk.PhotoImage(Image.open("nids.jpeg"))
image = Label(root, image=img, height=350, width=700)
image.pack()

#declare the open button
open_button = ttk.Button(
    root,
    text='Load Dataset',
    command=load_file
)

#declare the clear button
clear_button = ttk.Button(
    root,
    text='Clear',
    command=clear_result
)

open_button.pack(expand=True)
clear_button.pack(expand=True)

#declare the result area
text_area = st.ScrolledText(root,
                            wrap=tk.WORD,
                            width=700,
                            height=70,
                            font=("Times New Roman",
                                  13))
text_area.pack()

#start the main loop
root.mainloop()