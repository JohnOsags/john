#Osagiede John Osemwengie Work
# Import necessary libraries and modules
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import GradientBoostingClassifier
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestClassifier
import time

# Initialize global variables
features = ""
attack_names = {}


# Define a function to load feature names
def load_feature_names():
    global features
    features = """duration,
    protocol_type,
    service,
    flag,
    src_bytes,
    dst_bytes,
    land,
    wrong_fragment,
    urgent,
    hot,
    num_failed_logins,
    logged_in,
    num_compromised,
    root_shell,
    su_attempted,
    num_root,
    num_file_creations,
    num_shells,
    num_access_files,
    num_outbound_cmds,
    is_host_login,
    is_guest_login,
    count,
    srv_count,
    serror_rate,
    srv_serror_rate,
    rerror_rate,
    srv_rerror_rate,
    same_srv_rate,
    diff_srv_rate,
    srv_diff_host_rate,
    dst_host_count,
    dst_host_srv_count,
    dst_host_same_srv_rate,
    dst_host_diff_srv_rate,
    dst_host_same_src_port_rate,
    dst_host_srv_diff_host_rate,
    dst_host_serror_rate,
    dst_host_srv_serror_rate,
    dst_host_rerror_rate,
    dst_host_srv_rerror_rate"""

# Define a function to load attack types
def load_attack_types():
    global attack_names
    #define the attack types in a dictionary
    attack_names = {
        'normal': 'normal',
        'back': 'dos',
        'buffer_overflow': 'u2r',
        'ftp_write': 'r2l',
        'guess_passwd': 'r2l',
        'imap': 'r2l',
        'ipsweep': 'probe',
        'land': 'dos',
        'loadmodule': 'u2r',
        'multihop': 'r2l',
        'neptune': 'dos',
        'nmap': 'probe',
        'perl': 'u2r',
        'phf': 'r2l',
        'pod': 'dos',
        'portsweep': 'probe',
        'rootkit': 'u2r',
        'satan': 'probe',
        'smurf': 'dos',
        'spy': 'r2l',
        'teardrop': 'dos',
        'warezclient': 'r2l',
        'warezmaster': 'r2l',
    }


#DRIVER CODE
if __name__ == '__main__':
    print("Welcome to Network Intrusion Detection System")
    print("Loading the features.....")
    #load the feature names in a string
    load_feature_names()
    # load the attack names in a dictioanry
    print("Loading the attack types.....")
    load_attack_types()
    #iterate through the names and append to a list
    feature_names = []
    for feature in features.split(','):
        if (feature.strip()):
            feature_names.append(feature.strip())
    feature_names.append('target')

    print("Loading the intrusion data from KDD dataset...")
    #load the instrusion detection data from KDD cup dataset
    ids_dataset = "kddcup.data.gz"
    data_frame = pd.read_csv(ids_dataset, names=feature_names)
    #append the attack type column into the dataset , hence it will be useful for building the model
    data_frame['Attack Type'] = data_frame.target.apply(lambda r: attack_names[r[:-1]])
    print("Preprocessing the data.....")
    data_frame['target'].value_counts()
    data_frame['Attack Type'].value_counts()
    total_cols = data_frame._get_numeric_data().columns

    #Determine  the categorical features
    category_cols = list(set(data_frame.columns) - set(total_cols))
    category_cols.remove('target')
    category_cols.remove('Attack Type')
    #category_cols
    #data_frame.columns

    #remove the columns with NAN values
    data_frame = data_frame.dropna(axis=1)
    #retain the columns where there are omre than 1 unique values
    data_frame = data_frame[[col for col in data_frame if data_frame[col].nunique() > 1]]

    data_frame['num_root'].corr(data_frame['num_compromised'])
    data_frame['srv_serror_rate'].corr(data_frame['serror_rate'])
    data_frame['srv_count'].corr(data_frame['count'])
    data_frame['srv_rerror_rate'].corr(data_frame['rerror_rate'])
    data_frame['dst_host_same_srv_rate'].corr(data_frame['dst_host_srv_count'])
    data_frame['dst_host_srv_serror_rate'].corr(data_frame['dst_host_serror_rate'])
    data_frame['dst_host_srv_rerror_rate'].corr(data_frame['dst_host_rerror_rate'])
    data_frame['dst_host_same_srv_rate'].corr(data_frame['same_srv_rate'])
    data_frame['dst_host_srv_count'].corr(data_frame['same_srv_rate'])
    data_frame['dst_host_same_src_port_rate'].corr(data_frame['srv_count'])
    data_frame['dst_host_serror_rate'].corr(data_frame['serror_rate'])
    data_frame['dst_host_serror_rate'].corr(data_frame['srv_serror_rate'])
    data_frame['dst_host_srv_serror_rate'].corr(data_frame['serror_rate'])
    data_frame['dst_host_srv_serror_rate'].corr(data_frame['srv_serror_rate'])
    data_frame['dst_host_rerror_rate'].corr(data_frame['rerror_rate'])
    data_frame['dst_host_rerror_rate'].corr(data_frame['srv_rerror_rate'])
    data_frame['dst_host_srv_rerror_rate'].corr(data_frame['rerror_rate'])
    data_frame['dst_host_srv_rerror_rate'].corr(data_frame['srv_rerror_rate'])
    #drop the highly correlated columns, hence we
    #will build the best prediction model
    data_frame.drop('num_root', axis=1, inplace=True)
    data_frame.drop('srv_serror_rate', axis=1, inplace=True)
    data_frame.drop('srv_rerror_rate', axis=1, inplace=True)
    data_frame.drop('dst_host_srv_serror_rate', axis=1, inplace=True)
    data_frame.drop('dst_host_serror_rate', axis=1, inplace=True)
    data_frame.drop('dst_host_rerror_rate', axis=1, inplace=True)
    data_frame.drop('dst_host_srv_rerror_rate', axis=1, inplace=True)
    data_frame.drop('dst_host_same_srv_rate', axis=1, inplace=True)

    #df_std = data_frame.std()
    #df_std = df_std.sort_values(ascending=True)
    data_frame['protocol_type'].value_counts()

    #This block of code performs the feature mapping on
    # features such as protocl type and flag

    #map the features according to the protocol
    protocol_map = {'icmp': 0, 'tcp': 1, 'udp': 2}
    data_frame['protocol_type'] = data_frame['protocol_type'].map(protocol_map)
    data_frame['flag'].value_counts()

    #define the feature map
    feature_map = {'SF': 0, 'S0': 1, 'REJ': 2, 'RSTR': 3, 'RSTO': 4, 'SH': 5, 'S1': 6, 'S2': 7, 'RSTOS0': 8, 'S3': 9, 'OTH': 10}
    #set the flag data in dataframe
    data_frame['flag'] = data_frame['flag'].map(feature_map)
    #drop the service data
    data_frame.drop('service', axis=1, inplace=True)
    data_frame.shape
    data_frame.dtypes

    data_frame = data_frame.drop(['target', ], axis=1)
    #consider the attack type as the Y data
    YData = data_frame[['Attack Type']]
    # consider others as the X data
    XData = data_frame.drop(['Attack Type', ], axis=1)

    #perform the transformation of the data in order to split it
    scalarObject = MinMaxScaler()
    XData = scalarObject.fit_transform(XData)
    print("Training the dataset.....")
    X_train, X_test, y_train, y_test = train_test_split(XData, YData, test_size=0.33, random_state=42)

    clfs = SVC(gamma = 'scale')
    start_time = time.time()
    clfs.fit(X_train, y_train.values.ravel())
    end_time = time.time()
    print("SVM Training time ", end_time-start_time)
    start_time = time.time()
    y_test_pred = clfs.predict(X_train)
    end_time = time.time()
    print("SVM  Testing time ", end_time-start_time)
    print("SVM  Train score :", clfs.score(X_train, y_train))
    print("SVM  Test score :", clfs.score(X_test, y_test))


    clfr = RandomForestClassifier(n_estimators = 30)
    start_time = time.time()
    clfr.fit(X_train, y_train.values.ravel())
    end_time = time.time()
    print("RandomForest Training time: ", end_time-start_time)
    start_time = time.time()
    y_test_pred = clfr.predict(X_train)
    end_time = time.time()
    print("RandomForest Testing time: ", end_time-start_time)
    print("RandomForest Train score :", clfr.score(X_train, y_train))
    print("RandomForest Test score :", clfr.score(X_test, y_test))


    gausianNB = GaussianNB()
    start_time = time.time()
    gausianNB.fit(X_train, y_train.values.ravel())
    end_time = time.time()
    print("Gaussian Training time: ", end_time - start_time)
    start_time = time.time()
    y_test_pred = gausianNB.predict(X_train)
    end_time = time.time()
    print("Gaussian Testing time: ", end_time - start_time)
    print("Gaussian Train score :", gausianNB.score(X_train, y_train))
    print("Gaussian Test score :", gausianNB.score(X_test, y_test))



    clfd = DecisionTreeClassifier(criterion ="entropy", max_depth = 4)
    start_time = time.time()
    clfd.fit(X_train, y_train.values.ravel())
    end_time = time.time()
    print(" DecisionTree Training time: ", end_time-start_time)
    start_time = time.time()
    y_test_pred = clfd.predict(X_train)
    end_time = time.time()
    print("DecisionTree Testing time: ", end_time-start_time)
    print("DecisionTree Train score :", clfd.score(X_train, y_train))
    print("DecisionTree Test score :", clfd.score(X_test, y_test))


    clfl = LogisticRegression(max_iter = 1200000)
    start_time = time.time()
    clfl.fit(X_train, y_train.values.ravel())
    end_time = time.time()
    print("LogisticRegression Training time: ", end_time-start_time)
    start_time = time.time()
    y_test_pred = clfl.predict(X_train)
    end_time = time.time()
    print("LogisticRegression Testing time: ", end_time-start_time)
    print("LogisticRegression Train score :", clfl.score(X_train, y_train))
    print("LogisticRegression Test score :", clfl.score(X_test, y_test))



    clfg = GradientBoostingClassifier(random_state = 0)
    start_time = time.time()
    clfg.fit(X_train, y_train.values.ravel())
    end_time = time.time()
    print("GradientBoosting Training time: ", end_time-start_time)
    start_time = time.time()
    y_test_pred = clfg.predict(X_train)
    end_time = time.time()
    print("GradientBoosting Testing time: ", end_time-start_time)
    print("GradientBoosting Train score :", clfg.score(X_train, y_train))
    print("GradientBoosting Test score :", clfg.score(X_test, y_test))



